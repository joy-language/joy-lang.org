/* semantic tableaux */
/* Using explicit links to implement continuation */

#include <stdio.h>
#include <setjmp.h>
					/* Reading a formula : */
#define maxcode 200
jmp_buf begin;
int echo = 0;
char ch;
struct {char op; int left;} code[maxcode];
int cx;
void getch();
void error();
void generate(char c, int l);
void formula();
void expression();
void term();
void factor();

void getch()
{
do { ch = getchar(); if (echo) putchar(ch); }
    while (ch <= ' ');
}
void error(char * mes)
{
    printf("error: seen '%c' when %s\n",ch,mes);
    do ch = getchar(); while (ch != '\n');
    longjmp(begin,0);
}
void generate(char c, int l)
{
    cx++;
    code[cx].op = c; code[cx].left = l;
}
void formula()
{
    char localchar; int left;
    expression();
    if (ch == '>' || ch == '=')
      { localchar = ch; left = cx; getch();
	formula();
	generate(localchar,left); }
}
void expression()
{
    int left;
    term();
    if (ch == 'v')
      { left = cx; getch();
	expression();
	generate('#',left); }
}
void term()
{
    int left;
    factor();
    if (ch == '&')
      { getch(); left = cx;
	term();
	generate('&',left); }
}
void factor()
{
    if (ch >= 'a' && ch <= 'z')
      { generate('a',ch); getch(); }
    else if (ch == '-')
      { getch(); factor(); generate('-',0); }
    else if (ch == '(')
      { getch(); formula();
	if (ch == ')') getch();
	    else error("')' expected"); }
    else error("'a'..'z','-' or '(' expected");
}
					/* Generating the tableaux */
#define UNIT(c) (1 << (c - 'a'))
#define ADD(c,set) set = set |  UNIT(c)
#define REM(c,set) set = set & ~UNIT(c)
#define  IN(c,set) (set & UNIT(c)) > 0
#define bool char
struct {bool g; int f; int cp;} links[maxcode];
int lastlink;
int vars[2];
int num_models;
int newcp(bool g, int f, int cp);
void callcp(int cp);
void make(bool g, int f, int cp);

int newcp(bool g, int f, int cp)
{
    lastlink++;
    links[lastlink].g = g;
    links[lastlink].f = f;
    links[lastlink].cp = cp;
    return lastlink;
}
void callcp(int cp)
{
    char c;
    if (cp >= 0) make(links[cp].g,links[cp].f,links[cp].cp);
    else
      { if (num_models == 0)
	    printf("not tautology, countermodels:\n");
	num_models++;
	printf("%d:  ",num_models);
	for (c = 'a'; c <= 'z'; c++)
	  { if (IN(c,vars[1])) printf(" +%c",c); else
	    if (IN(c,vars[0])) printf(" -%c",c); }
	printf("\n"); }
}
void make(bool g, int f, int cp)
{
    char op = code[f].op;
    int left = code[f].left;
    int right = f - 1;
    switch (op)
      { case 'a' :
	    if (!IN(left,vars[!g]))
	      { if (IN(left,vars[g])) callcp(cp); else
		  { ADD(left,vars[g]);
		    callcp(cp);
		    REM(left,vars[g]); } }
	    break;
        case '-' :
	    make(!g,right,cp);
	    break;
	case '&': case '#' :
	    if ((op == '&') == g)
		make(g,left,newcp(g,right,cp));
	    else
	      { make(g,left,cp); make(g,right,cp); }
	    break;
	case '>' :
	    if (g)
	      { make(0,left,cp); make(1,right,cp); }
	    else
		make(1,left,newcp(0,right,cp));
	    break;
	case '=' :
	    make(g,left,newcp(1,right,cp));
	    make(!g,left,newcp(0,right,cp));
	    break; }
}
void main()
{
    setjmp(begin);
    do
      { printf("?- "); getch();
	if (ch == '!') { echo = 1; getch(); }
	cx = -1; formula();
	if (ch != '.')  error("'.' expected");
	num_models = 0; lastlink = -1; make(0,cx,-1);
	if (num_models == 0) printf("tautology\n"); }
    while (1);
}
