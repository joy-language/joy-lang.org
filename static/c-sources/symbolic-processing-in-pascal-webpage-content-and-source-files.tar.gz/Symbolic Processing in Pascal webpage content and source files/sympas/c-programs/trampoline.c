
> PROGRAM oddevn(input,output);

I translated the program into GNU C (it will not work in ANSI C, of course):

===== cut here =====

# include <stdio.h>

typedef void (*proc)();

int eoln() {
int i;
i = getchar();
if (i == '\n') return 1;
ungetc(i, stdin);
return 0;
}

int eof() {
int i;
i = getchar();
if (i == EOF) return 1;
ungetc(i, stdin);
return 0;
}

void space() {
printf(&quot; &quot;);
}

void odev(proc cp) {
int n;

void writelater() {
cp();
printf(&quot;%d &quot;, n);
}

if (eoln()) cp();
else {
scanf(&quot;%d&quot;, &amp;n);
if (n % 2 == 0) {
printf(&quot;%d &quot;, n);
odev(cp);
}
else
odev(writelater);
}
}

int main() {
while (!eof()) {
odev(space);
printf(&quot;\n&quot;);
}
}

===== cut here =====

> It would be of interest to me to know whether gcc can handle
> this sort of thing (as I mentioned before, the version of p2c
> that I once tried failed.) 

It works, most definitely. It took a bit of debugging to get right, basically
because of oversights in my hand-translation, and I had to research the
semantics of eoln and eof in Pascal to realize that they involve lookahead.

-- 
