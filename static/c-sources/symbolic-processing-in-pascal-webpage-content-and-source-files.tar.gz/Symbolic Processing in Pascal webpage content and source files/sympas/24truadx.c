/* semantic tableaux */
/* Using stack addresses to implement continuation */

#include <stdio.h>
#include <setjmp.h>
					/* Reading a formula : */
#define maxcode 200
jmp_buf begin;
int echo = 0;
char ch;
struct {char op; int left;} code[maxcode];
int cx;
void getch();
void error();
void generate(char c, int l);
void formula();
void expression();
void term();
void factor();

void getch()
{
do { ch = getchar(); if (echo) putchar(ch); }
    while (ch <= ' ');
}
void error(char * mes)
{
    printf("error: seen '%c' when %s\n",ch,mes);
    do ch = getchar(); while (ch != '\n');
    longjmp(begin,0);
}
void generate(char c, int l)
{
    cx++;
    code[cx].op = c; code[cx].left = l;
}
void formula()
{
    char localchar; int left;
    expression();
    if (ch == '>' || ch == '=')
      { localchar = ch; left = cx; getch();
	formula();
	generate(localchar,left); }
}
void expression()
{
    int left;
    term();
    if (ch == 'v')
      { left = cx; getch();
	expression();
	generate('#',left); }
}
void term()
{
    int left;
    factor();
    if (ch == '&')
      { getch(); left = cx;
	term();
	generate('&',left); }
}
void factor()
{
    if (ch >= 'a' && ch <= 'z')
      { generate('a',ch); getch(); }
    else if (ch == '-')
      { getch(); factor(); generate('-',0); }
    else if (ch == '(')
      { getch(); formula();
	if (ch == ')') getch();
	    else error("')' expected"); }
    else error("'a'..'z','-' or '(' expected");
}
					/* Generating the tableaux */
#define UNIT(c) (1 << (c - 'a'))
#define ADD(c,set) set = set |  UNIT(c)
#define REM(c,set) set = set & ~UNIT(c)
#define  IN(c,set) (set & UNIT(c)) > 0
#define bool char
int vars[2];
int num_models;
void callcp(int cp);
void make(bool g, int f, int cp);

void callcp(int cp)
{
    char c;
    if (cp >= 0) make(*(int *)(cp+16), *(int *)(cp+8), *(int*)cp);
    else
      { if (num_models == 0)
	    printf("not tautology, countermodels:\n");
	num_models++;
	printf("%d:  ",num_models);
	for (c = 'a'; c <= 'z'; c++)
	  { if (IN(c,vars[1])) printf(" +%c",c); else
	    if (IN(c,vars[0])) printf(" -%c",c); }
	printf("\n"); }
}
int dummy;
void make(bool g, int f, int cp)
{
    #define OP code[f].op
    #define LEFT code[f].left
    #define RIGHT f - 1
    #define NEXT(G,F) (newg = G, newf = F, newcp = cp, (int)&newcp)
    bool newg;
    int newf,newcp;
    dummy = (int)&newg + (int)&newf + (int)&newcp;
    switch (OP)
      { case 'a' :
	    if (!IN(LEFT,vars[!g]))
	      { if (IN(LEFT,vars[g])) callcp(cp); else
		  { ADD(LEFT,vars[g]);
		    callcp(cp);
		    REM(LEFT,vars[g]); } }
	    break;
        case '-' :
	    make(!g,RIGHT,cp);
	    break;
	case '&': case '#' :
	    if ((OP == '&') == g)
		make(g,LEFT,NEXT(g,RIGHT));
	    else
	      { make(g,LEFT,cp); make(g,RIGHT,cp); }
	    break;
	case '>' :
	    if (g)
	      { make(0,LEFT,cp); make(1,RIGHT,cp); }
	    else
		make(1,LEFT,NEXT(0,RIGHT));
	    break;
	case '=' :
	    make(g,LEFT,NEXT(1,RIGHT));
	    make(!g,LEFT,NEXT(0,RIGHT));
	    break; }
}
void main()
{
    setjmp(begin);
    do
      { printf("?- "); getch();
	if (ch == '!') { echo = 1; getch(); }
	cx = -1; formula();
	if (ch != '.')  error("'.' expected");
	num_models = 0; make(0,cx,-1);
	if (num_models == 0) printf("tautology\n"); }
    while (1);
}
