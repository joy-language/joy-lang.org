/* regular expression expander */
/* using stack addresses to implement continuation */


#include <stdio.h>
#include <setjmp.h>
					/* Reading an expression : */
#define maxcode 200
jmp_buf begin;
int echo = 0;
char ch;
struct {char op; int left;} code[maxcode];
int cx;
void getch();
void error();
void generate(char c, int l);
void expression();
void term();
void factor();

void getch()
{
do { ch = getchar(); if (echo) putchar(ch); }
    while (ch <= ' ');
}
void error(char * mes)
{
    printf("error: seen '%c' when %s\n",ch,mes);
    do ch = getchar(); while (ch != '\n');
    longjmp(begin,0);
}
void generate(char c, int l)
{
    cx++;
    code[cx].op = c; code[cx].left = l;
}
void expression()
{
    int left;
    term();
    if (ch == '|')
      { left = cx; getch();
	expression();
	generate('|',left); }
}
void term()
{
    int left;
    factor();
    if (ch >= 'a' && ch <= 'z'  ||  ch == '0'  ||  ch == '(')
      { left = cx;
	term();
	generate('_',left); }
}
void factor()
{
    if (ch >= 'a' && ch <= 'z')
      { generate(ch,0); getch(); }
    else if (ch == '0')
      { generate('0',0); getch(); }
    else if (ch == '(')
      { getch(); expression();
	if (ch == ')') getch();
	    else error("')' expected"); }
    else error("'a'..'z','0' or '(' expected");
    while (ch == '*' || ch == '+' || ch == '?')
      { generate(ch,0); getch(); }
}
					/* Generating the strings */
#define MAXSTRING 50
char s[MAXSTRING];
int p,m;
void putch(char c, int cp);
void expand(int t, int cp);

void putch(char c, int cp)
{
    int i;
    s[++p] = c;
    if (cp > 0) expand(*(int *)(cp + 8), *(int *)cp);
    else
      { for (i = 0; i <= p; i++) printf("%c",s[i]);
	printf("\n"); }
    p--;
}
int dummy;
void expand(int t, int cp)
{
    int newt,newcp;
    #define OP code[t].op
    #define LEFT code[t].left
    #define RIGHT (t-1)
    #define NEXT(T)  (newt = T, newcp = cp, (int)&newcp)
    dummy = (int)&newt - (int)&newcp; /* delete this at your peril ! */
    if (p < m)
	switch (OP)
	  { case '0' :
		putch(0,cp);
		break;
	    case '_' :
		expand(LEFT,NEXT(RIGHT));
		break;
	    case '|' :
		expand(LEFT,cp);
		expand(RIGHT,cp);
		break;
	    case '*' :
		putch(0,cp);
		expand(RIGHT,NEXT(t));
		break;
	    case '+' :
		expand(RIGHT,cp);
		expand(RIGHT,NEXT(t));
		break;
	    case '?' :
		putch(0,cp);
		expand(RIGHT,cp);
		break;
	    default :
		putch(OP,cp);
		break; }
}
void main()
{
    int finished = 0;
    setjmp(begin);
    do
      { printf("?- "); getch();
	if (ch == '!') { echo = 1; getch(); }
	if (ch != '.')
	  { cx = -1; expression();
	    if (ch != '.')  error("'.' expected");
	    do
	      { printf("current maximum [0..%d]\n",MAXSTRING);
		scanf("%d",&m);
		if (m > MAXSTRING) m = MAXSTRING;
		if (m > 0)
		 { p = -1; expand(cx,0); } }
	    while (m > 0); }
	else finished = 1; }
    while (!finished);
}
